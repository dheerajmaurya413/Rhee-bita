"""Package: infniversal_consciousness_nexus"""
from .consciousness_quantization import ConsciousnessQuantizer
from .nexus_synchronization import ConsciousnessNexusSynchronizer

__all__ = ["ConsciousnessQuantizer", "ConsciousnessNexusSynchronizer"]
