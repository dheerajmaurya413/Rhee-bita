"""Package: omniversal_consciousness_synthesizer"""
from .consciousness_synthesis import OmniversalConsciousnessSynthesizer
from .synthesis_harmonization import ConsciousnessSynthesisHarmonizer

__all__ = ["OmniversalConsciousnessSynthesizer", "ConsciousnessSynthesisHarmonizer"]
