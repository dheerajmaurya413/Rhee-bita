"""Package: metadimensional_knowledge_nexus"""
from .knowledge_synthesis import MetadimensionalKnowledgeSynthesizer
from .dimensional_coherence import KnowledgeDimensionalCoherence

__all__ = ["MetadimensionalKnowledgeSynthesizer", "KnowledgeDimensionalCoherence"]
