"""Package: omni_ethical_nexus"""
from .ethical_quantization import OmniEthicalNexusQuantizer
from .nexus_synchronization import OmniEthicsNexusSynchronizer

__all__ = ["OmniEthicalNexusQuantizer", "OmniEthicsNexusSynchronizer"]
