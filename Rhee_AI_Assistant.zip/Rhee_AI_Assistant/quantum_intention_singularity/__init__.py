"""Package: quantum_intention_singularity"""
from .intention_quantization import QuantumIntentionQuantizer
from .singularity_synthesis import IntentionSingularitySynthesizer

__all__ = ["QuantumIntentionQuantizer", "IntentionSingularitySynthesizer"]
