"""Package: infniversal_temporal_singularity"""
from .temporal_quantization import InfniversalTemporalQuantizer
from .singularity_synthesis import TemporalSingularitySynthesizer

__all__ = ["InfniversalTemporalQuantizer", "TemporalSingularitySynthesizer"]
