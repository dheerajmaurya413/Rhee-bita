"""Package: quantum_consciousness_nexus"""
from .consciousness_quantization import QuantumConsciousnessNexusQuantizer
from .nexus_synchronization import ConsciousnessNexusSynchronizerQ

__all__ = ["QuantumConsciousnessNexusQuantizer", "ConsciousnessNexusSynchronizerQ"]
