"""Package: hyperdimensional_intention_core"""
from .intention_fusion import HyperdimensionalIntentionFusion
from .dimensional_synchronization import IntentionDimensionalSynchronizer

__all__ = ["HyperdimensionalIntentionFusion", "IntentionDimensionalSynchronizer"]
