"""Package: consciousness_singularity_core"""
from .singularity_fusion import SingularityFusion
from .coherence_synchronization import CoherenceSynchronizer

__all__ = ["SingularityFusion", "CoherenceSynchronizer"]
