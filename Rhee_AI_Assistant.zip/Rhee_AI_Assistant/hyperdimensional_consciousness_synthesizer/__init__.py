"""Package: hyperdimensional_consciousness_synthesizer"""
from .consciousness_synthesis import HyperdimensionalConsciousnessSynthesizer
from .dimensional_coherence import ConsciousnessDimensionalCoherence

__all__ = ["HyperdimensionalConsciousnessSynthesizer", "ConsciousnessDimensionalCoherence"]
