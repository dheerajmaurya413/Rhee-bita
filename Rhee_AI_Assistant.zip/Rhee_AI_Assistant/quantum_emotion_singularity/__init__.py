"""Package: quantum_emotion_singularity"""
from .emotion_quantization import EmotionQuantizationSingularity
from .singularity_coherence import EmotionSingularityCoherence

__all__ = ["EmotionQuantizationSingularity", "EmotionSingularityCoherence"]
