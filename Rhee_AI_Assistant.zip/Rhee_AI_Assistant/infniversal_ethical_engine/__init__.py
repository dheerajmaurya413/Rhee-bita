"""Package: infniversal_ethical_engine"""
from .ethical_synthesis import InfniversalEthicalSynthesizer
from .engine_optimization import EthicsEngineOptimizer

__all__ = ["InfniversalEthicalSynthesizer", "EthicsEngineOptimizer"]
