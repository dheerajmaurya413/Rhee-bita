"""Package: hyperethical_consciousness_core"""
from .consciousness_synthesis import HyperEthicalConsciousnessSynthesizer
from .ethical_coherence import ConsciousnessEthicsCoherence

__all__ = ["HyperEthicalConsciousnessSynthesizer", "ConsciousnessEthicsCoherence"]
