"""Package: hypercausal_emotion_engine"""
from .emotion_synthesis import HypercausalEmotionSynthesizer
from .causal_amplification import EmotionCausalAmplifier

__all__ = ["HypercausalEmotionSynthesizer", "EmotionCausalAmplifier"]
