"""Package: hyperspatial_consciousness_engine"""
from .consciousness_synthesis import HyperspatialConsciousnessSynthesizer
from .spatial_amplification import SpatialAmplifier

__all__ = ["HyperspatialConsciousnessSynthesizer", "SpatialAmplifier"]
