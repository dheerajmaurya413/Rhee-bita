"""Package: transdimensional_knowledge_core"""
from .knowledge_fusion import KnowledgeFusion
from .dimensional_resonance import DimensionalResonance

__all__ = ["KnowledgeFusion", "DimensionalResonance"]
