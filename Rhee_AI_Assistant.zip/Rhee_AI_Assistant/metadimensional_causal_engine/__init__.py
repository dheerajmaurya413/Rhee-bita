"""Package: metadimensional_causal_engine"""
from .causal_synthesis import MetadimensionalCausalSynthesizer
from .dimensional_amplification import CausalDimensionalAmplifier

__all__ = ["MetadimensionalCausalSynthesizer", "CausalDimensionalAmplifier"]
