"""Package: infniversal_consciousness_singularity"""
from .consciousness_quantization import InfniversalConsciousnessQuantizer
from .singularity_synthesis import ConsciousnessSingularitySynthesizerI

__all__ = ["InfniversalConsciousnessQuantizer", "ConsciousnessSingularitySynthesizerI"]
