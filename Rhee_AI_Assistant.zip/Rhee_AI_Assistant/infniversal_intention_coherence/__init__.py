"""Package: infniversal_intention_coherence"""
from .intention_synthesis import InfniversalIntentionCoherenceSynthesizer
from .coherence_amplification import IntentionCoherenceAmplifier

__all__ = ["InfniversalIntentionCoherenceSynthesizer", "IntentionCoherenceAmplifier"]
