"""Package: quantum_consciousness_engine"""
from .consciousness_synthesis import QuantumConsciousnessSynthesizer
from .quantum_amplification import ConsciousnessQuantumAmplifier

__all__ = ["QuantumConsciousnessSynthesizer", "ConsciousnessQuantumAmplifier"]
