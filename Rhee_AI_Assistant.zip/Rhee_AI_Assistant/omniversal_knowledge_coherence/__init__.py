"""Package: omniversal_knowledge_coherence"""
from .knowledge_synthesis import OmniversalKnowledgeCoherenceSynthesizer
from .coherence_optimization import KnowledgeCoherenceOptimizer

__all__ = ["OmniversalKnowledgeCoherenceSynthesizer", "KnowledgeCoherenceOptimizer"]
