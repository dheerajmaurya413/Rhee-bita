"""Causal Convergence - Identifies converging causes toward a common effect."""
from collections import defaultdict
from loguru import logger

class CausalConvergence:
    """Identifies multiple causes converging toward a shared effect."""

    def __init__(self):
        self._effect_map: dict = defaultdict(list)

    def add_cause(self, cause: str, effect: str, weight: float = 1.0) -> None:
        self._effect_map[effect].append({"cause": cause, "weight": weight})

    def convergence_point(self) -> str:
        """Find the effect with the most converging causes."""
        if not self._effect_map:
            return "unknown"
        return max(self._effect_map, key=lambda e: sum(c["weight"] for c in self._effect_map[e]))

    def get_causes(self, effect: str) -> list:
        return self._effect_map.get(effect, [])

    def convergence_score(self, effect: str) -> float:
        causes = self._effect_map.get(effect, [])
        return sum(c["weight"] for c in causes)
