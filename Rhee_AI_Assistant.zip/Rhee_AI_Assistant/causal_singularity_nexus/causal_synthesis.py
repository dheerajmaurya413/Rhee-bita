"""Causal Synthesis - Builds causal chains from events and reasoning steps."""
from loguru import logger

class CausalSynthesizer:
    """Synthesizes causal chains: cause -> effect -> consequence reasoning."""

    def __init__(self):
        self._chains: list = []

    def add_link(self, cause: str, effect: str, confidence: float = 1.0) -> None:
        self._chains.append({"cause": cause, "effect": effect, "confidence": confidence})
        logger.debug(f"Causal link: {cause} -> {effect}")

    def synthesize_chain(self, start: str) -> list:
        """Trace full causal chain from a starting point."""
        chain = []
        current = start
        visited = set()
        while current and current not in visited:
            visited.add(current)
            next_link = next((l for l in self._chains if l["cause"] == current), None)
            if not next_link:
                break
            chain.append(next_link)
            current = next_link["effect"]
        return chain

    def explain_chain(self, start: str) -> str:
        """Generate a human-readable causal explanation."""
        chain = self.synthesize_chain(start)
        if not chain:
            return f"No causal chain found from: {start}"
        parts = [f"{l['cause']} leads to {l['effect']}" for l in chain]
        return " -> ".join(parts)

    def clear(self):
        self._chains.clear()
