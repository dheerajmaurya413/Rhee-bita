"""Package: hyperdimensional_ethical_synthesizer"""
from .ethical_synthesis import HyperdimensionalEthicalSynthesizer
from .dimensional_coherence import EthicsDimensionalCoherence

__all__ = ["HyperdimensionalEthicalSynthesizer", "EthicsDimensionalCoherence"]
