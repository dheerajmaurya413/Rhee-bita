"""Package: quantum_ethical_nexus"""
from .ethical_quantization import QuantumEthicalNexusQuantizer
from .nexus_synchronization import EthicsNexusSynchronizerQ

__all__ = ["QuantumEthicalNexusQuantizer", "EthicsNexusSynchronizerQ"]
