"""Package: quantum_emotion_resonance"""
from .emotion_quantization import QuantumEmotionQuantizer
from .resonance_synthesis import EmotionQuantumResonanceSynthesizer

__all__ = ["QuantumEmotionQuantizer", "EmotionQuantumResonanceSynthesizer"]
