"""Reality Coherence - Ensures generated responses maintain logical and contextual coherence."""
import re
from loguru import logger

class RealityCoherence:
    """Validates and scores the coherence of generated responses."""

    INCOHERENCE_PATTERNS = [
        r"\bI don't know\b.{0,30}\bI know\b",
        r"\byes\b.{0,20}\bno\b",
        r"\btrue\b.{0,20}\bfalse\b",
    ]

    def __init__(self):
        self._compiled = [re.compile(p, re.IGNORECASE) for p in self.INCOHERENCE_PATTERNS]

    def score(self, response: str) -> float:
        """Return coherence score 0-1 for a generated response."""
        deductions = 0.0
        for pattern in self._compiled:
            if pattern.search(response):
                deductions += 0.2
        words = response.split()
        if len(words) < 3:
            deductions += 0.3
        score = max(0.0, 1.0 - deductions)
        logger.debug(f"Coherence score: {score:.2f}")
        return score

    def is_coherent(self, response: str, threshold: float = 0.6) -> bool:
        return self.score(response) >= threshold

    def fix_incoherence(self, response: str) -> str:
        """Attempt minor fixes for detected incoherence."""
        fixed = response.strip()
        if not fixed.endswith((".", "!", "?")):
            fixed += "."
        return fixed
