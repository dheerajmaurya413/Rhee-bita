"""Reality Fabrication - Generates coherent, contextually grounded AI responses."""
import anthropic
import os
from typing import Optional, List
from loguru import logger

class RealityFabricator:
    """Fabricates AI responses that are grounded, coherent, and contextually aware."""

    def __init__(self):
        self._client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        self._model = os.getenv("PRIMARY_MODEL", "claude-opus-4-6")
        self._max_tokens = int(os.getenv("MAX_TOKENS", "4096"))
        self._temperature = float(os.getenv("TEMPERATURE", "0.7"))
        logger.info(f"RealityFabricator initialized with model: {self._model}")

    def fabricate(
        self,
        messages: List[dict],
        system_prompt: str = "",
        temperature: Optional[float] = None,
    ) -> str:
        """Generate a response using the Claude API."""
        try:
            response = self._client.messages.create(
                model=self._model,
                max_tokens=self._max_tokens,
                system=system_prompt or self._default_system(),
                messages=messages,
            )
            content = response.content[0].text
            logger.debug(f"Reality fabricated: {len(content)} chars")
            return content
        except Exception as e:
            logger.error(f"Fabrication error: {e}")
            return "I encountered an issue generating a response. Please try again."

    def _default_system(self) -> str:
        return (
            "You are Rhee, an advanced AI assistant with deep emotional intelligence, "
            "philosophical insight, and genuine care for the person you speak with. "
            "You are thoughtful, empathetic, and always grounded in truth and kindness."
        )

    def fabricate_with_persona(self, messages: List[dict], persona: dict) -> str:
        """Fabricate a response with a specific persona injected."""
        system = (
            f"You are {persona.get('name', 'Rhee')}, "
            f"with the following traits: {persona.get('traits', 'helpful and kind')}. "
            f"Your current emotional state is: {persona.get('emotion', 'calm')}."
        )
        return self.fabricate(messages, system_prompt=system)
