"""Reality Stabilization - Prevents response hallucination and maintains factual grounding."""
from loguru import logger

HALLUCINATION_FLAGS = [
    "as a fact", "it is certain", "100% true", "guaranteed",
    "I can confirm without doubt", "absolutely certain",
]

class RealityStabilization:
    """Stabilizes AI output by flagging and softening overconfident or hallucinated claims."""

    def stabilize(self, response: str) -> str:
        """Detect and soften overconfident language in a response."""
        stabilized = response
        changes = 0
        for phrase in HALLUCINATION_FLAGS:
            if phrase.lower() in stabilized.lower():
                stabilized = stabilized.replace(phrase, "it appears that")
                changes += 1
        if changes:
            logger.warning(f"Stabilized {changes} overconfident claim(s)")
        return stabilized

    def confidence_level(self, response: str) -> str:
        """Estimate confidence level of response: high/medium/low."""
        hedges = ["perhaps", "maybe", "might", "could be", "possibly", "I think", "it seems"]
        high_conf = ["definitely", "certainly", "absolutely", "always", "never"]
        text_lower = response.lower()
        hedge_count = sum(1 for h in hedges if h in text_lower)
        conf_count = sum(1 for h in high_conf if h in text_lower)
        if conf_count > hedge_count:
            return "high"
        elif hedge_count > 0:
            return "low"
        return "medium"
