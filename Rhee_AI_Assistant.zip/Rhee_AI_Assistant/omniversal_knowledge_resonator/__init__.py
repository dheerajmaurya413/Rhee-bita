"""Package: omniversal_knowledge_resonator"""
from .knowledge_quantization import KnowledgeQuantizer
from .resonance_synthesis import KnowledgeResonanceSynthesizer

__all__ = ["KnowledgeQuantizer", "KnowledgeResonanceSynthesizer"]
