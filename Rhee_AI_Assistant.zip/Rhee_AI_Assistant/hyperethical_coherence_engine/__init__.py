"""Package: hyperethical_coherence_engine"""
from .ethical_synthesis import HyperEthicalSynthesizer
from .coherence_amplification import EthicsCoherenceAmplifier

__all__ = ["HyperEthicalSynthesizer", "EthicsCoherenceAmplifier"]
