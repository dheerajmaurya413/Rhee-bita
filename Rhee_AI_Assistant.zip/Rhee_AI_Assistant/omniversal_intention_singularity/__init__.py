"""Package: omniversal_intention_singularity"""
from .intention_quantization import OmniversalIntentionSingularityQuantizer
from .singularity_synthesis import IntentionSingularitySynthesizerO

__all__ = ["OmniversalIntentionSingularityQuantizer", "IntentionSingularitySynthesizerO"]
