"""Package: hyperconsciousness_knowledge_nexus"""
from .knowledge_synthesis import HyperconsciousnessKnowledgeNexusSynthesizer
from .consciousness_coherence import KnowledgeConsciousnessCoherence

__all__ = ["HyperconsciousnessKnowledgeNexusSynthesizer", "KnowledgeConsciousnessCoherence"]
