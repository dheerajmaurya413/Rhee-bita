"""Tests for Transinfinite Intention Modulator."""
import pytest


@pytest.fixture
def synthesizer():
    from transinfinite_intention_modulator.intention_synthesis import IntentionSynthesizer
    return IntentionSynthesizer()


def test_synthesizer_detects_query(synthesizer):
    result = synthesizer.synthesize("What is the meaning of life?")
    assert result["primary"] == "query"


def test_synthesizer_detects_command(synthesizer):
    result = synthesizer.synthesize("Create a Python script for me.")
    assert result["primary"] == "command"


def test_synthesizer_detects_emotional(synthesizer):
    result = synthesizer.synthesize("I feel so happy and emotional today!")
    assert result["primary"] == "emotional"


def test_synthesizer_confidence_range(synthesizer):
    result = synthesizer.synthesize("Hello there!")
    assert 0 <= result["confidence"] <= 1


def test_synthesizer_urgency_high(synthesizer):
    urgency = synthesizer.classify_urgency("This is URGENT help me now!")
    assert urgency == "high"


def test_synthesizer_urgency_low(synthesizer):
    urgency = synthesizer.classify_urgency("Maybe sometime you could tell me about trees")
    assert urgency == "low"


@pytest.fixture
def aligner():
    from transinfinite_intention_modulator.intention_alignment import IntentionAligner
    return IntentionAligner()


def test_aligner_maps_query(aligner):
    result = aligner.align({"primary": "query", "secondary": [], "confidence": 0.9})
    assert "knowledge_retrieval" in result["activated_capabilities"]


def test_aligner_maps_creative(aligner):
    result = aligner.align({"primary": "creative", "secondary": [], "confidence": 0.8})
    assert "content_generation" in result["activated_capabilities"]


@pytest.fixture
def resonance():
    from transinfinite_intention_modulator.intention_resonance import IntentionResonance
    return IntentionResonance()


def test_resonance_records_and_scores(resonance):
    resonance.record("query")
    resonance.record("query")
    resonance.record("command")
    score = resonance.resonate("query")
    assert score == pytest.approx(2/3)


def test_resonance_dominant(resonance):
    for _ in range(5):
        resonance.record("emotional")
    resonance.record("query")
    assert resonance.dominant_intention() == "emotional"
