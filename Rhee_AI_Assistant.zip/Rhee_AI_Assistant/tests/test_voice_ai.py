"""Tests for Voice AI subsystem."""
import pytest
from unittest.mock import MagicMock, patch


@pytest.fixture
def emotion_detector():
    from voice_ai.emotion_detector import EmotionDetector
    return EmotionDetector()


def test_emotion_detector_detects_anger(emotion_detector):
    emotion = emotion_detector.detect("I am so angry and furious right now!")
    assert emotion == "angry"


def test_emotion_detector_detects_sadness(emotion_detector):
    emotion = emotion_detector.detect("I feel so sad and heartbroken today")
    assert emotion == "sad"


def test_emotion_detector_detects_excitement(emotion_detector):
    emotion = emotion_detector.detect("I am thrilled and ecstatic about this!")
    assert emotion == "excited"


def test_emotion_detector_fallback_positive(emotion_detector):
    emotion = emotion_detector.detect("This is wonderful and amazing!")
    assert emotion_detector.get_valence(emotion) > 0


def test_emotion_detector_get_valence(emotion_detector):
    assert emotion_detector.get_valence("happy") == 0.0  # unknown maps to 0
    assert emotion_detector.get_valence("angry") < 0
    assert emotion_detector.get_valence("excited") > 0


def test_emotion_detector_analyze_full_structure(emotion_detector):
    result = emotion_detector.analyze_full("I love this so much!")
    assert "emotion" in result
    assert "valence" in result
    assert "confidence" in result
    assert "sentiment_scores" in result


@pytest.fixture
def voice_manager():
    with patch("voice_ai.voice_core.pyttsx3.init") as mock_tts,          patch("voice_ai.voice_core.sr.Recognizer"):
        mock_engine = MagicMock()
        mock_tts.return_value = mock_engine
        from voice_ai.voice_manager import VoiceManager
        return VoiceManager()


def test_voice_manager_initializes(voice_manager):
    assert voice_manager is not None
    assert voice_manager.current_emotion == "calm"


def test_voice_manager_set_emotion(voice_manager):
    voice_manager.set_emotion("excited")
    assert voice_manager.current_emotion == "excited"


def test_voice_manager_get_status(voice_manager):
    status = voice_manager.get_status()
    assert "active" in status
    assert "current_emotion" in status
    assert "tts_available" in status
