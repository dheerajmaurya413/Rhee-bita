"""Tests for Omnipotent Reality Synthesis."""
import pytest
from unittest.mock import MagicMock, patch


def test_reality_coherence_score_good():
    from omnipotent_reality_synthesis.reality_coherence import RealityCoherence
    rc = RealityCoherence()
    score = rc.score("This is a well-formed and coherent response about the topic.")
    assert score >= 0.6


def test_reality_coherence_score_bad():
    from omnipotent_reality_synthesis.reality_coherence import RealityCoherence
    rc = RealityCoherence()
    score = rc.score("Yes no true false")
    assert score < 1.0


def test_reality_coherence_is_coherent():
    from omnipotent_reality_synthesis.reality_coherence import RealityCoherence
    rc = RealityCoherence()
    assert rc.is_coherent("The sky is blue and the grass is green.")


def test_reality_stabilizer_softens_overconfidence():
    from omnipotent_reality_synthesis.reality_stabilization import RealityStabilization
    rs = RealityStabilization()
    stabilized = rs.stabilize("As a fact, the answer is always 42.")
    assert "As a fact" not in stabilized


def test_reality_stabilizer_confidence_level():
    from omnipotent_reality_synthesis.reality_stabilization import RealityStabilization
    rs = RealityStabilization()
    assert rs.confidence_level("This is definitely certainly the answer.") == "high"
    assert rs.confidence_level("Perhaps it might be the case.") == "low"
    assert rs.confidence_level("The answer is 42.") == "medium"


def test_reality_fabricator_default_system():
    with patch("omnipotent_reality_synthesis.reality_fabrication.anthropic"):
        from omnipotent_reality_synthesis.reality_fabrication import RealityFabricator
        rf = RealityFabricator()
        system = rf._default_system()
        assert "Rhee" in system
