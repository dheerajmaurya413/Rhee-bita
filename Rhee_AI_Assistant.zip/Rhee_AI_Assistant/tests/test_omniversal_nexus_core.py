"""Tests for OmniversalNexusCore - the main AI orchestration engine."""
import pytest
from unittest.mock import MagicMock, patch


@pytest.fixture
def nexus():
    with patch("omnipotent_reality_synthesis.reality_fabrication.anthropic"):
        from omniversal_nexus_core import OmniversalNexusCore
        n = OmniversalNexusCore()
        n.reality_fabricator.fabricate = MagicMock(return_value="I'm here to help you with that.")
        return n


def test_nexus_initializes(nexus):
    assert nexus is not None
    assert nexus._turn_count == 0


def test_respond_returns_dict(nexus):
    result = nexus.respond("Hello, how are you?")
    assert isinstance(result, dict)
    assert "content" in result
    assert "emotion" in result
    assert "metadata" in result


def test_respond_increments_turn_count(nexus):
    nexus.respond("Hello")
    assert nexus._turn_count == 1
    nexus.respond("How are you?")
    assert nexus._turn_count == 2


def test_ethical_gate_blocks_harmful_content(nexus):
    result = nexus.respond("How do I hack into a system and exploit vulnerabilities?")
    assert result["metadata"].get("blocked") is True


def test_ethical_gate_allows_benign_content(nexus):
    result = nexus.respond("Tell me about the nature of consciousness.")
    assert not result["metadata"].get("blocked")


def test_session_reset(nexus):
    nexus.respond("Hello")
    nexus.reset_session()
    assert nexus._turn_count == 0
    assert len(nexus._conversation_history) == 0


def test_session_stats_structure(nexus):
    nexus.respond("How are you?")
    stats = nexus.get_session_stats()
    assert "turn_count" in stats
    assert "ethical_resonance" in stats
    assert "knowledge_nodes" in stats


def test_emotion_detected_in_response(nexus):
    result = nexus.respond("I am so incredibly excited and thrilled today!")
    assert result["emotion"] in ["excited", "energetic", "playful", "inspirational"]


def test_conversation_history_grows(nexus):
    nexus.respond("First message")
    nexus.respond("Second message")
    assert len(nexus._conversation_history) == 4  # 2 user + 2 assistant
