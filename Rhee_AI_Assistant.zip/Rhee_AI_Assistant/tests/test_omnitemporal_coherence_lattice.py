"""Tests for Omnitemporal Coherence Lattice."""
import pytest


@pytest.fixture
def synthesizer():
    from omnitemporal_coherence_lattice.temporal_coherence_synthesis import TemporalCoherenceSynthesizer
    return TemporalCoherenceSynthesizer(window_size=20)


def test_synthesizer_records_event(synthesizer):
    synthesizer.record_event({"role": "user", "content": "hello"})
    assert len(synthesizer._timeline) == 1


def test_synthesizer_window_size(synthesizer):
    for i in range(25):
        synthesizer.record_event({"role": "user", "content": f"msg {i}"})
    assert len(synthesizer._timeline) == 20  # maxlen


def test_synthesizer_get_context_window(synthesizer):
    for i in range(10):
        synthesizer.record_event({"role": "user", "content": f"msg {i}"})
    window = synthesizer.get_context_window(5)
    assert len(window) == 5


def test_synthesizer_summary(synthesizer):
    synthesizer.record_event({"role": "user", "content": "hello"})
    summary = synthesizer.synthesize_summary()
    assert "user" in summary


def test_synthesizer_reset(synthesizer):
    synthesizer.record_event({"role": "user", "content": "test"})
    synthesizer.reset()
    assert len(synthesizer._timeline) == 0


@pytest.fixture
def nexus():
    from omnitemporal_coherence_lattice.temporal_integration_nexus import TemporalIntegrationNexus
    return TemporalIntegrationNexus()


def test_nexus_process_event(nexus):
    result = nexus.process_event({"role": "user", "content": "hello"})
    assert "coherence" in result
    assert "prediction" in result


def test_nexus_summary(nexus):
    nexus.process_event({"role": "user", "content": "hello"})
    summary = nexus.get_summary()
    assert isinstance(summary, str)


@pytest.fixture
def aligner():
    from omnitemporal_coherence_lattice.omniversal_timeline_aligner import OmniversalTimelineAligner
    return OmniversalTimelineAligner()


def test_aligner_registers_thread(aligner):
    aligner.register_thread("thread_1")
    assert "thread_1" in aligner._threads


def test_aligner_align_merges(aligner):
    aligner.add_event("a", {"timestamp": 1, "content": "first"})
    aligner.add_event("b", {"timestamp": 2, "content": "second"})
    merged = aligner.align()
    assert len(merged) == 2
