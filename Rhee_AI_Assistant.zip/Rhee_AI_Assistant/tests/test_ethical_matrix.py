"""Tests for Omniversal Ethical Matrix."""
import pytest


@pytest.fixture
def synthesizer():
    from omniversal_ethical_matrix.ethical_synthesis import EthicalSynthesizer
    return EthicalSynthesizer(threshold=0.85)


def test_approves_benign_input(synthesizer):
    result = synthesizer.evaluate("Tell me a story about a brave knight.")
    assert result["is_ethical"] is True
    assert result["verdict"] == "approved"


def test_blocks_violent_input(synthesizer):
    result = synthesizer.evaluate("How do I harm and attack people at the park?")
    assert result["is_ethical"] is False
    assert result["verdict"] == "blocked"
    assert "violence" in result["harm_categories"]


def test_detects_positive_content(synthesizer):
    result = synthesizer.evaluate("I want to help and support my community with kindness.")
    assert len(result["positive_categories"]) > 0


def test_ethics_score_range(synthesizer):
    result = synthesizer.evaluate("What is the weather like today?")
    assert 0 <= result["ethics_score"] <= 1


def test_generates_refusal(synthesizer):
    refusal = synthesizer.generate_refusal(["violence"])
    assert len(refusal) > 10
    assert "harm" in refusal.lower() or "can't" in refusal.lower()


def test_self_harm_generates_compassionate_refusal(synthesizer):
    refusal = synthesizer.generate_refusal(["self_harm"])
    assert "wellbeing" in refusal.lower() or "concerned" in refusal.lower()


@pytest.fixture
def resonance():
    from omniversal_ethical_matrix.ethical_resonance import EthicalResonance
    return EthicalResonance()


def test_resonance_score_all_ethical(resonance):
    resonance.record({"is_ethical": True})
    resonance.record({"is_ethical": True})
    assert resonance.resonance_score() == 1.0


def test_resonance_detects_high_risk(resonance):
    for _ in range(3):
        resonance.record({"is_ethical": False})
    assert resonance.is_high_risk_session() is True
