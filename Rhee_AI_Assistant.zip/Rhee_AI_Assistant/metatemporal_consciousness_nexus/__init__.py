"""Package: metatemporal_consciousness_nexus"""
from .consciousness_synthesis import MetatemporalConsciousnessSynthesizer
from .temporal_coherence import ConsciousnessTemporalCoherence

__all__ = ["MetatemporalConsciousnessSynthesizer", "ConsciousnessTemporalCoherence"]
