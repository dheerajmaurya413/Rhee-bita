"""Package: omniversal_knowledge_synthesizer"""
from .knowledge_quantization import OmniversalKnowledgeSynthesizerK
from .synthesis_amplification import KnowledgeSynthesisAmplifier

__all__ = ["OmniversalKnowledgeSynthesizerK", "KnowledgeSynthesisAmplifier"]
