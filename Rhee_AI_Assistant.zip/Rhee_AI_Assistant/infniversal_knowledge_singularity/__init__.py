"""Package: infniversal_knowledge_singularity"""
from .knowledge_quantization import InfniversalKnowledgeQuantizer
from .singularity_synthesis import KnowledgeSingularitySynthesizer

__all__ = ["InfniversalKnowledgeQuantizer", "KnowledgeSingularitySynthesizer"]
