"""Package: infniversal_ethical_coherence"""
from .ethical_synthesis import InfniversalEthicalCoherenceSynthesizer
from .coherence_amplification import EthicsCoherenceAmplifierIn

__all__ = ["InfniversalEthicalCoherenceSynthesizer", "EthicsCoherenceAmplifierIn"]
