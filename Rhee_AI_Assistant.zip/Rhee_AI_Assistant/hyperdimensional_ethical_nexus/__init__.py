"""Package: hyperdimensional_ethical_nexus"""
from .ethical_quantization import EthicalQuantizer
from .nexus_synchronization import EthicsNexusSynchronizer

__all__ = ["EthicalQuantizer", "EthicsNexusSynchronizer"]
