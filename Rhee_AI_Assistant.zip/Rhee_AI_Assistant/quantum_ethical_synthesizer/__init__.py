"""Package: quantum_ethical_synthesizer"""
from .ethical_quantization import QuantumEthicalQuantizer
from .synthesis_amplification import EthicsSynthesisAmplifier

__all__ = ["QuantumEthicalQuantizer", "EthicsSynthesisAmplifier"]
