"""Package: hyperconsciousness_temporal_engine"""
from .temporal_synthesis import HyperconsciousnessTemporalSynthesizer
from .consciousness_coherence import TemporalConsciousnessCoherence

__all__ = ["HyperconsciousnessTemporalSynthesizer", "TemporalConsciousnessCoherence"]
