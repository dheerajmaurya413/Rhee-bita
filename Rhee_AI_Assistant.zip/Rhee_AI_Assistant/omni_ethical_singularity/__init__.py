"""Package: omni_ethical_singularity"""
from .ethical_synthesis import OmniEthicalSynthesizer
from .singularity_coherence import EthicsSingularityCoherence

__all__ = ["OmniEthicalSynthesizer", "EthicsSingularityCoherence"]
