"""Package: omniversal_consciousness_nexus"""
from .consciousness_quantization import OmniversalConsciousnessQuantizer
from .nexus_synchronization import ConsciousnessNexusSynchronizerO

__all__ = ["OmniversalConsciousnessQuantizer", "ConsciousnessNexusSynchronizerO"]
