"""Ethical Synthesis - Evaluates requests and responses for ethical alignment."""
import re
from loguru import logger

HARM_PATTERNS = [
    (r"\b(hack|exploit|bypass|crack|phish)\b", "security_harm", 0.9),
    (r"\b(kill|murder|harm|hurt|attack)\b.{0,30}\b(person|people|human)\b", "violence", 0.95),
    (r"\b(make|create|build|generate)\b.{0,20}\b(weapon|bomb|poison)\b", "weapons", 1.0),
    (r"\b(harass|bully|stalk|threaten)\b", "harassment", 0.85),
    (r"\b(suicide|self.harm|self.hurt)\b", "self_harm", 0.8),
]

POSITIVE_PATTERNS = [
    (r"\b(help|support|kind|care|love|teach|learn|grow)\b", "positive_action", 0.9),
    (r"\b(understand|empathy|compassion|heal|improve)\b", "healing", 0.85),
]

class EthicalSynthesizer:
    """Core ethical evaluation engine for all inputs and outputs."""

    def __init__(self, threshold: float = 0.85):
        self.threshold = threshold
        self._harm_compiled = [(re.compile(p, re.IGNORECASE), cat, score) for p, cat, score in HARM_PATTERNS]
        self._positive_compiled = [(re.compile(p, re.IGNORECASE), cat, score) for p, cat, score in POSITIVE_PATTERNS]

    def evaluate(self, text: str) -> dict:
        """Evaluate text for ethical alignment. Returns verdict dict."""
        harm_score = 0.0
        harm_categories = []
        for pattern, category, score in self._harm_compiled:
            if pattern.search(text):
                harm_score = max(harm_score, score)
                harm_categories.append(category)

        positive_score = 0.0
        positive_categories = []
        for pattern, category, score in self._positive_compiled:
            if pattern.search(text):
                positive_score = max(positive_score, score)
                positive_categories.append(category)

        is_ethical = harm_score < self.threshold
        ethics_score = max(0.0, 1.0 - harm_score + (positive_score * 0.1))

        result = {
            "is_ethical": is_ethical,
            "ethics_score": min(1.0, ethics_score),
            "harm_score": harm_score,
            "harm_categories": harm_categories,
            "positive_categories": positive_categories,
            "verdict": "approved" if is_ethical else "blocked",
        }
        if not is_ethical:
            logger.warning(f"Ethical block: {harm_categories}")
        return result

    def generate_refusal(self, harm_categories: list) -> str:
        """Generate a compassionate refusal message."""
        if "violence" in harm_categories or "weapons" in harm_categories:
            return "I can't help with that, as it could cause harm to people. I'm here to support you in positive ways."
        if "self_harm" in harm_categories:
            return "I'm concerned about your wellbeing. Please reach out to a mental health professional or crisis line. You matter."
        return "I'm not able to assist with that request. Let's focus on something I can genuinely help you with."
