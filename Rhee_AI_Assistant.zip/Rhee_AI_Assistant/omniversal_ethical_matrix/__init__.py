"""Package: OmniversalEthicalMatrix"""
from .ethicalsynthesizer import EthicalSynthesizer
from .ethicalresonance import EthicalResonance

__all__ = ["EthicalSynthesizer", "EthicalResonance"]
