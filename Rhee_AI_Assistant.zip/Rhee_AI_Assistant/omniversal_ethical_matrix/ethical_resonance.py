"""Ethical Resonance - Tracks ethical alignment over time and detects drift."""
from loguru import logger

class EthicalResonance:
    """Tracks ethical alignment history and detects patterns of misuse."""

    def __init__(self):
        self._history: list = []
        self._violation_count = 0

    def record(self, evaluation: dict) -> None:
        self._history.append(evaluation)
        if not evaluation.get("is_ethical", True):
            self._violation_count += 1
            logger.warning(f"Ethical violation recorded. Total: {self._violation_count}")

    def resonance_score(self) -> float:
        """Overall ethical resonance score based on history."""
        if not self._history:
            return 1.0
        ethical_count = sum(1 for e in self._history if e.get("is_ethical", True))
        return ethical_count / len(self._history)

    def is_high_risk_session(self) -> bool:
        """Detect if the session shows a pattern of harmful intent."""
        return self._violation_count >= 3

    def reset_session(self) -> None:
        self._history.clear()
        self._violation_count = 0
