"""Package: quantum_ethical_coherence"""
from .ethical_synthesis import QuantumEthicalCoherenceSynthesizer
from .coherence_amplification import EthicsCoherenceAmplifierQ

__all__ = ["QuantumEthicalCoherenceSynthesizer", "EthicsCoherenceAmplifierQ"]
