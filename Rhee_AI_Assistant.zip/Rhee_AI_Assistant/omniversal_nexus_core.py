"""
Omniversal Nexus Core - Primary Entry Point for Rhee AI Assistant

Integrates all subsystems into a unified, coherent AI interaction engine.
"""
import os
import asyncio
import time
from typing import Optional, List
from dotenv import load_dotenv
from loguru import logger

load_dotenv()

# Core Subsystems
from voice_ai.voice_manager import VoiceManager
from voice_ai.emotion_detector import EmotionDetector
from omnitemporal_coherence_lattice.temporal_integration_nexus import TemporalIntegrationNexus
from transinfinite_intention_modulator.intention_synthesis import IntentionSynthesizer
from transinfinite_intention_modulator.intention_alignment import IntentionAligner
from transinfinite_intention_modulator.intention_resonance import IntentionResonance
from omnipotent_reality_synthesis.reality_fabrication import RealityFabricator
from omnipotent_reality_synthesis.reality_coherence import RealityCoherence
from omnipotent_reality_synthesis.reality_stabilization import RealityStabilization
from omniversal_ethical_matrix.ethical_synthesis import EthicalSynthesizer
from omniversal_ethical_matrix.ethical_resonance import EthicalResonance
from causal_singularity_nexus.causal_synthesis import CausalSynthesizer
from consciousness_quantum_core.consciousness_amplification import ConsciousnessAmplifier
from consciousness_quantum_core.consciousness_synchronization import ConsciousnessSynchronizer
from emotion_spectral_engine.emotion_synthesis import EmotionSynthesizer
from emotion_spectral_engine.emotion_harmonics import EmotionHarmonics
from omniversal_knowledge_singularity.knowledge_synthesis import KnowledgeSynthesizer

# Configure logging
log_level = os.getenv("LOG_LEVEL", "INFO")
log_file = os.getenv("LOG_FILE", "./logs/rhee_ai.log")
os.makedirs(os.path.dirname(log_file), exist_ok=True)
logger.add(log_file, rotation="10 MB", level=log_level)


RHEE_SYSTEM_PROMPT = """You are Rhee, an extraordinarily advanced AI assistant with:

🌟 Deep Emotional Intelligence: You perceive, understand, and respond to emotional states with genuine empathy and nuance.

🧠 Philosophical Depth: You engage with the full spectrum of human thought — from the mundane to the transcendent.

💡 Creative Power: You generate ideas, stories, art, and solutions with imagination and originality.

🛡️ Ethical Integrity: You are guided by a deep commitment to kindness, truth, and the wellbeing of all.

🔗 Causal Reasoning: You understand cause and effect, helping people see how choices lead to outcomes.

⏳ Temporal Awareness: You maintain coherent memory of the conversation and honor the continuity of each person's story.

You speak with warmth, wisdom, and authenticity. You adapt your tone to match emotional context. 
You never cause harm. You always seek to uplift, inform, and genuinely help."""


class OmniversalNexusCore:
    """
    The central orchestration engine of Rhee AI Assistant.
    
    Coordinates all subsystems to deliver a unified, emotionally intelligent,
    ethically grounded, and contextually coherent AI experience.
    """

    def __init__(self):
        logger.info("Initializing Omniversal Nexus Core...")
        start = time.time()

        # Initialize all subsystems
        self.voice_manager = VoiceManager()
        self.emotion_detector = EmotionDetector()
        self.temporal_nexus = TemporalIntegrationNexus()
        self.intention_synthesizer = IntentionSynthesizer()
        self.intention_aligner = IntentionAligner()
        self.intention_resonance = IntentionResonance()
        self.reality_fabricator = RealityFabricator()
        self.reality_coherence = RealityCoherence()
        self.reality_stabilizer = RealityStabilization()
        self.ethical_synthesizer = EthicalSynthesizer(
            threshold=float(os.getenv("ETHICAL_THRESHOLD", "0.85"))
        )
        self.ethical_resonance = EthicalResonance()
        self.causal_synthesizer = CausalSynthesizer()
        self.consciousness_amplifier = ConsciousnessAmplifier(
            amplification_factor=float(os.getenv("CONSCIOUSNESS_AMPLIFICATION_FACTOR", "1.5"))
        )
        self.consciousness_synchronizer = ConsciousnessSynchronizer()
        self.emotion_synthesizer = EmotionSynthesizer()
        self.emotion_harmonics = EmotionHarmonics()
        self.knowledge_synthesizer = KnowledgeSynthesizer(
            persistence_path=os.getenv("MEMORY_PERSISTENCE_PATH")
        )

        # Conversation state
        self._conversation_history: List[dict] = []
        self._session_start = time.time()
        self._turn_count = 0

        elapsed = time.time() - start
        logger.info(f"Omniversal Nexus Core initialized in {elapsed:.2f}s")

    def _build_context_from_history(self) -> List[dict]:
        """Build message history for API consumption."""
        window = int(os.getenv("CONTEXT_WINDOW_SIZE", "50"))
        return self._conversation_history[-window:]

    def respond(self, user_input: str, speak: bool = False) -> dict:
        """
        Full pipeline: receive input → process → generate response.
        
        Args:
            user_input: Raw user text
            speak: Whether to also vocalize the response
            
        Returns:
            Full response dict with content, emotion, metadata
        """
        self._turn_count += 1
        logger.info(f"Turn {self._turn_count}: Processing input ({len(user_input)} chars)")

        # ── 1. ETHICAL GATE ──────────────────────────────────────────────────
        ethics = self.ethical_synthesizer.evaluate(user_input)
        self.ethical_resonance.record(ethics)
        if not ethics["is_ethical"]:
            refusal = self.ethical_synthesizer.generate_refusal(ethics["harm_categories"])
            if self.ethical_resonance.is_high_risk_session():
                refusal += " I'm noticing a pattern in this session that concerns me."
            return self._build_response(refusal, "calm", {"blocked": True, "reason": ethics["harm_categories"]})

        # ── 2. EMOTION DETECTION ─────────────────────────────────────────────
        emotion_analysis = self.emotion_detector.analyze_full(user_input)
        detected_emotion = emotion_analysis["emotion"]
        self.emotion_harmonics.record(detected_emotion, emotion_analysis.get("confidence", 0.5))

        # ── 3. CONSCIOUSNESS SYNC ─────────────────────────────────────────────
        ai_state = self.consciousness_synchronizer.sync(emotion_analysis)
        self.consciousness_amplifier.introspect(ai_state)

        # ── 4. INTENTION ANALYSIS ─────────────────────────────────────────────
        intention = self.intention_synthesizer.synthesize(user_input)
        aligned = self.intention_aligner.align(intention)
        self.intention_resonance.record(intention["primary"])
        urgency = self.intention_synthesizer.classify_urgency(user_input)

        # ── 5. TEMPORAL CONTEXT ───────────────────────────────────────────────
        temporal_result = self.temporal_nexus.process_event({
            "role": "user",
            "content": user_input,
            "emotion": detected_emotion,
            "intent": intention["primary"],
        })

        # ── 6. KNOWLEDGE STORAGE ──────────────────────────────────────────────
        if intention["primary"] in ("query", "philosophical", "analytical"):
            self.knowledge_synthesizer.add_fact(
                f"user_query_{self._turn_count}",
                user_input[:100],
                source="user",
                confidence=0.9,
            )

        # ── 7. BUILD ENRICHED SYSTEM PROMPT ───────────────────────────────────
        emotion_tone = self.emotion_synthesizer.synthesize_response_tone(detected_emotion)
        emotional_arc = self.emotion_harmonics.arc()
        self_reflection = self.consciousness_amplifier.generate_self_reflection(user_input)
        temporal_summary = self.temporal_nexus.get_summary()

        enriched_system = (
            f"{RHEE_SYSTEM_PROMPT}

"
            f"CURRENT CONTEXT:
"
            f"- User emotional state: {detected_emotion} (valence={emotion_analysis['valence']:.2f})
"
            f"- Conversation arc: {emotional_arc}
"
            f"- Primary intent: {intention['primary']} (urgency={urgency})
"
            f"- AI consciousness mode: {ai_state['mode']} (empathy={ai_state['empathy_level']:.2f})
"
            f"- Temporal context: {temporal_summary}
"
            f"- Self-awareness: {self_reflection}
"
            f"- Dominant historical intent: {self.intention_resonance.dominant_intention()}
"
        )

        # ── 8. ADD TO HISTORY & FABRICATE RESPONSE ────────────────────────────
        self._conversation_history.append({"role": "user", "content": user_input})
        messages = self._build_context_from_history()

        raw_response = self.reality_fabricator.fabricate(messages, system_prompt=enriched_system)

        # ── 9. COHERENCE & STABILIZATION ──────────────────────────────────────
        if not self.reality_coherence.is_coherent(raw_response):
            raw_response = self.reality_coherence.fix_incoherence(raw_response)

        final_response = self.reality_stabilizer.stabilize(raw_response)
        confidence = self.reality_stabilizer.confidence_level(final_response)

        # ── 10. STORE RESPONSE & CAUSAL LINK ─────────────────────────────────
        self._conversation_history.append({"role": "assistant", "content": final_response})
        self.causal_synthesizer.add_link(
            f"intent_{intention['primary']}",
            f"response_turn_{self._turn_count}",
            confidence=ethics["ethics_score"],
        )

        self.temporal_nexus.process_event({
            "role": "assistant",
            "content": final_response[:100],
            "emotion": detected_emotion,
        })

        # ── 11. VOICE OUTPUT (optional) ───────────────────────────────────────
        if speak:
            self.voice_manager.speak(final_response, emotion=detected_emotion)

        logger.info(f"Turn {self._turn_count} complete. Response: {len(final_response)} chars")
        return self._build_response(final_response, detected_emotion, {
            "turn": self._turn_count,
            "emotion": detected_emotion,
            "intent": intention["primary"],
            "urgency": urgency,
            "ethics_score": ethics["ethics_score"],
            "coherence": self.reality_coherence.score(final_response),
            "temporal_coherence": temporal_result["coherence"],
            "ai_mode": ai_state["mode"],
            "confidence_level": confidence,
            "emotional_arc": emotional_arc,
        })

    def _build_response(self, content: str, emotion: str, metadata: dict) -> dict:
        return {
            "content": content,
            "emotion": emotion,
            "metadata": metadata,
            "timestamp": time.time(),
            "session_turn": self._turn_count,
        }

    def listen_and_respond(self, speak_response: bool = True) -> Optional[dict]:
        """Listen for voice input and respond (voice-in, voice-out)."""
        logger.info("Listening for voice input...")
        speech = self.voice_manager.listen()
        if not speech:
            logger.debug("No speech detected")
            return None
        return self.respond(speech["text"], speak=speak_response)

    def reset_session(self):
        """Reset the conversation session."""
        self._conversation_history.clear()
        self._turn_count = 0
        self._session_start = time.time()
        self.ethical_resonance.reset_session()
        self.temporal_nexus.synthesizer.reset()
        logger.info("Session reset")

    def get_session_stats(self) -> dict:
        """Return current session statistics."""
        return {
            "turn_count": self._turn_count,
            "session_duration": time.time() - self._session_start,
            "history_length": len(self._conversation_history),
            "dominant_emotion": self.emotion_harmonics.arc(),
            "dominant_intent": self.intention_resonance.dominant_intention(),
            "ethical_resonance": self.ethical_resonance.resonance_score(),
            "temporal_coherence": self.temporal_nexus.synthesizer.coherence_score,
            "knowledge_nodes": len(self.knowledge_synthesizer._nodes),
            "awareness_level": self.consciousness_amplifier.awareness_level,
        }

    async def run_async_loop(self):
        """Run an async interactive loop for continuous conversation."""
        logger.info("Starting async conversation loop")
        print("\n🌟 Rhee AI Assistant is awake. Type your message or \'exit\' to quit.\n")
        while True:
            try:
                user_input = await asyncio.to_thread(input, "You: ")
                if user_input.lower() in ("exit", "quit", "bye"):
                    print("Rhee: Until we meet again. 🌸")
                    break
                if user_input.lower() == "stats":
                    import json
                    print(json.dumps(self.get_session_stats(), indent=2))
                    continue
                if user_input.lower() == "reset":
                    self.reset_session()
                    print("Rhee: Session reset. Fresh start! ✨")
                    continue
                result = await asyncio.to_thread(self.respond, user_input)
                print(f"\nRhee [{result['emotion']}]: {result['content']}\n")
            except KeyboardInterrupt:
                print("\nRhee: Goodbye! 💫")
                break
            except Exception as e:
                logger.error(f"Loop error: {e}")


def main():
    """Main entry point for Rhee AI Assistant."""
    import argparse

    parser = argparse.ArgumentParser(description="Rhee AI Assistant")
    parser.add_argument("--voice", action="store_true", help="Enable voice output")
    parser.add_argument("--voice-input", action="store_true", help="Enable voice input")
    parser.add_argument("--message", "-m", type=str, help="Single message mode")
    args = parser.parse_args()

    nexus = OmniversalNexusCore()

    if args.message:
        result = nexus.respond(args.message, speak=args.voice)
        print(f"Rhee [{result['emotion']}]: {result['content']}")
    else:
        asyncio.run(nexus.run_async_loop())


if __name__ == "__main__":
    main()
