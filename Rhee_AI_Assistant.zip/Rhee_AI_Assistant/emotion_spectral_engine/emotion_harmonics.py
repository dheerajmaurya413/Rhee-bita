"""Emotion Harmonics - Tracks emotional harmonics across conversation."""
import math
from loguru import logger

class EmotionHarmonics:
    """Tracks and harmonizes emotional patterns over a conversation arc."""

    def __init__(self):
        self._history: list = []

    def record(self, emotion: str, intensity: float = 1.0) -> None:
        self._history.append({"emotion": emotion, "intensity": intensity})

    def harmonic_mean_valence(self, valence_map: dict) -> float:
        """Compute harmonic mean of recent emotional valences."""
        if not self._history:
            return 0.0
        valences = [valence_map.get(e["emotion"], 0.0) for e in self._history[-10:]]
        valences = [v for v in valences if v != 0]
        if not valences:
            return 0.0
        return len(valences) / sum(1/v for v in valences)

    def arc(self) -> str:
        """Describe the emotional arc of the conversation."""
        if len(self._history) < 3:
            return "stable"
        recent = [e["emotion"] for e in self._history[-5:]]
        negative = {"sad", "angry", "fearful", "sarcastic"}
        positive = {"excited", "happy", "inspirational", "romantic", "playful"}
        neg_count = sum(1 for e in recent if e in negative)
        pos_count = sum(1 for e in recent if e in positive)
        if pos_count > neg_count + 1:
            return "rising"
        elif neg_count > pos_count + 1:
            return "falling"
        return "stable"
