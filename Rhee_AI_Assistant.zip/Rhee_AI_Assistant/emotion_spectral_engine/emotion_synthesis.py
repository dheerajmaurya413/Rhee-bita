"""Emotion Synthesis - Synthesizes complex blended emotional states."""
from loguru import logger

EMOTION_SPECTRUM = {
    "calm": {"valence": 0.2, "arousal": 0.1, "color": "#87CEEB"},
    "gentle": {"valence": 0.3, "arousal": 0.15, "color": "#DDA0DD"},
    "sad": {"valence": -0.6, "arousal": 0.2, "color": "#708090"},
    "angry": {"valence": -0.7, "arousal": 0.9, "color": "#DC143C"},
    "excited": {"valence": 0.8, "arousal": 0.9, "color": "#FFD700"},
    "fearful": {"valence": -0.5, "arousal": 0.8, "color": "#800080"},
    "playful": {"valence": 0.7, "arousal": 0.7, "color": "#FF69B4"},
    "romantic": {"valence": 0.8, "arousal": 0.5, "color": "#FF1493"},
    "mysterious": {"valence": 0.1, "arousal": 0.4, "color": "#4B0082"},
    "spiritual": {"valence": 0.7, "arousal": 0.3, "color": "#E6E6FA"},
    "inspirational": {"valence": 0.9, "arousal": 0.7, "color": "#FF8C00"},
    "confident": {"valence": 0.7, "arousal": 0.6, "color": "#4169E1"},
    "caring": {"valence": 0.8, "arousal": 0.4, "color": "#32CD32"},
    "epic": {"valence": 0.9, "arousal": 1.0, "color": "#B8860B"},
    "dreamy": {"valence": 0.5, "arousal": 0.2, "color": "#B0C4DE"},
    "sleepy": {"valence": 0.0, "arousal": -0.1, "color": "#2F4F4F"},
    "professional": {"valence": 0.3, "arousal": 0.4, "color": "#36454F"},
    "sarcastic": {"valence": -0.2, "arousal": 0.5, "color": "#808000"},
}

class EmotionSynthesizer:
    """Synthesizes and blends emotional states for nuanced AI responses."""

    def get_profile(self, emotion: str) -> dict:
        return EMOTION_SPECTRUM.get(emotion, EMOTION_SPECTRUM["calm"])

    def blend(self, emotion_a: str, emotion_b: str, ratio: float = 0.5) -> dict:
        """Blend two emotions with a given ratio (0=all A, 1=all B)."""
        profile_a = self.get_profile(emotion_a)
        profile_b = self.get_profile(emotion_b)
        blended_valence = profile_a["valence"] * (1 - ratio) + profile_b["valence"] * ratio
        blended_arousal = profile_a["arousal"] * (1 - ratio) + profile_b["arousal"] * ratio
        logger.debug(f"Blended emotions: {emotion_a}+{emotion_b} at ratio {ratio}")
        return {"valence": blended_valence, "arousal": blended_arousal, "blend": f"{emotion_a}_{emotion_b}"}

    def closest_named_emotion(self, valence: float, arousal: float) -> str:
        """Find the closest named emotion to given valence/arousal coordinates."""
        best, best_dist = "calm", float("inf")
        for name, profile in EMOTION_SPECTRUM.items():
            dist = ((profile["valence"] - valence) ** 2 + (profile["arousal"] - arousal) ** 2) ** 0.5
            if dist < best_dist:
                best, best_dist = name, dist
        return best

    def synthesize_response_tone(self, emotion: str) -> dict:
        """Return tone instructions for response generation."""
        profile = self.get_profile(emotion)
        return {
            "emotion": emotion,
            "warmth": max(0, profile["valence"]),
            "energy": profile["arousal"],
            "verbosity": "detailed" if profile["arousal"] > 0.5 else "concise",
        }
