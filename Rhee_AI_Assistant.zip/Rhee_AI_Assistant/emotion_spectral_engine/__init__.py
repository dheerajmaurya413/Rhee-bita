"""Emotion Spectral Engine - Advanced emotion processing and harmonics."""
from .emotion_synthesis import EmotionSynthesizer
from .emotion_harmonics import EmotionHarmonics

__all__ = ["EmotionSynthesizer", "EmotionHarmonics"]
