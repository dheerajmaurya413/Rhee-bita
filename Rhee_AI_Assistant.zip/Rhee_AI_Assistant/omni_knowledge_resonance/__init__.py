"""Package: omni_knowledge_resonance"""
from .knowledge_quantization import OmniKnowledgeQuantizer
from .resonance_amplification import KnowledgeResonanceAmplifier

__all__ = ["OmniKnowledgeQuantizer", "KnowledgeResonanceAmplifier"]
