"""Package: infniversal_reality_synthesizer"""
from .reality_quantization import InfniversalRealityQuantizer
from .synthesis_amplification import RealitySynthesisAmplifier

__all__ = ["InfniversalRealityQuantizer", "RealitySynthesisAmplifier"]
