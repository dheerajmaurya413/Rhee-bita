"""Package: quantum_reality_singularity"""
from .reality_quantization import QuantumRealitySingularityQuantizer
from .singularity_synthesis import RealitySingularitySynthesizer

__all__ = ["QuantumRealitySingularityQuantizer", "RealitySingularitySynthesizer"]
