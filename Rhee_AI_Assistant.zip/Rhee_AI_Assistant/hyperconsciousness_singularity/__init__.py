"""Package: hyperconsciousness_singularity"""
from .singularity_fusion import HyperConsciousnessSingularity
from .consciousness_synchronization import HyperConsciousnessSynchronizer

__all__ = ["HyperConsciousnessSingularity", "HyperConsciousnessSynchronizer"]
