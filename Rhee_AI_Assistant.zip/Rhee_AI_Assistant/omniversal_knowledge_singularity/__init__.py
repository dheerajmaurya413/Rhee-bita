"""Omniversal Knowledge Singularity - Knowledge retrieval, synthesis, and management."""
from .knowledge_synthesis import KnowledgeSynthesizer
from .knowledge_resonance import KnowledgeResonance

__all__ = ["KnowledgeSynthesizer", "KnowledgeResonance"]
