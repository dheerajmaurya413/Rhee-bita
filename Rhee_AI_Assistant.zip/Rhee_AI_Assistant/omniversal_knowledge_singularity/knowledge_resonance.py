"""Knowledge Resonance - Finds resonant knowledge patterns across the knowledge graph."""
from loguru import logger

class KnowledgeResonance:
    """Identifies resonant and connected knowledge patterns."""

    def __init__(self, synthesizer):
        self.synthesizer = synthesizer

    def find_resonant(self, query: str, top_k: int = 5) -> list:
        """Find knowledge nodes that resonate most strongly with a query."""
        results = self.synthesizer.search(query)
        return results[:top_k]

    def resonance_score(self, query: str, key: str) -> float:
        """Score how strongly a key resonates with a query."""
        if not key or not query:
            return 0.0
        q_words = set(query.lower().split())
        k_words = set(key.lower().replace("_", " ").split())
        intersection = q_words & k_words
        union = q_words | k_words
        return len(intersection) / len(union) if union else 0.0

    def build_resonance_map(self, queries: list) -> dict:
        """Build a map of queries to their most resonant knowledge nodes."""
        return {q: self.find_resonant(q) for q in queries}
