"""Knowledge Synthesis - Retrieves, indexes, and synthesizes knowledge."""
import json
import time
from pathlib import Path
from typing import Any, Optional
from loguru import logger

class KnowledgeSynthesizer:
    """Manages an in-memory knowledge graph with synthesis capabilities."""

    def __init__(self, persistence_path: Optional[str] = None):
        self._nodes: dict = {}
        self._edges: list = []
        self._persistence_path = persistence_path
        if persistence_path:
            self._load()

    def add_fact(self, key: str, value: Any, source: str = "user", confidence: float = 1.0) -> None:
        """Add a fact to the knowledge base."""
        self._nodes[key] = {
            "value": value,
            "source": source,
            "confidence": confidence,
            "timestamp": time.time(),
        }
        logger.debug(f"Fact added: {key} = {str(value)[:50]}")

    def link(self, key_a: str, key_b: str, relation: str) -> None:
        """Create a relationship between two knowledge nodes."""
        self._edges.append({"from": key_a, "to": key_b, "relation": relation})

    def query(self, key: str) -> Optional[Any]:
        """Retrieve a fact by key."""
        node = self._nodes.get(key)
        return node["value"] if node else None

    def search(self, query: str) -> list:
        """Search nodes by partial key or value match."""
        results = []
        q = query.lower()
        for key, node in self._nodes.items():
            if q in key.lower() or q in str(node["value"]).lower():
                results.append({"key": key, **node})
        results.sort(key=lambda r: r["confidence"], reverse=True)
        return results[:10]

    def synthesize_context(self, keys: list) -> str:
        """Generate a coherent text summary from a list of knowledge keys."""
        parts = []
        for key in keys:
            node = self._nodes.get(key)
            if node:
                parts.append(f"{key}: {node['value']}")
        return " | ".join(parts) if parts else "No relevant knowledge found."

    def _load(self):
        path = Path(self._persistence_path)
        if path.exists():
            try:
                data = json.loads(path.read_text())
                self._nodes = data.get("nodes", {})
                self._edges = data.get("edges", [])
                logger.info(f"Knowledge loaded from {path}: {len(self._nodes)} nodes")
            except Exception as e:
                logger.error(f"Failed to load knowledge: {e}")

    def save(self):
        if not self._persistence_path:
            return
        path = Path(self._persistence_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"nodes": self._nodes, "edges": self._edges}, indent=2))
        logger.info(f"Knowledge saved to {path}")
