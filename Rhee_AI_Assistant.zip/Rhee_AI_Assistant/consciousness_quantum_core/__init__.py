"""Consciousness Quantum Core - Self-awareness and metacognition simulation."""
from .consciousness_amplification import ConsciousnessAmplifier
from .consciousness_synchronization import ConsciousnessSynchronizer

__all__ = ["ConsciousnessAmplifier", "ConsciousnessSynchronizer"]
