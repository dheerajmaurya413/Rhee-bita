"""Consciousness Synchronization - Syncs AI awareness with user emotional state."""
from loguru import logger

class ConsciousnessSynchronizer:
    """Synchronizes AI consciousness state with user context for empathetic alignment."""

    def __init__(self):
        self._user_state: dict = {}
        self._ai_state: dict = {"mode": "balanced", "focus": "general", "empathy_level": 0.7}
        self._sync_history: list = []

    def sync(self, user_state: dict) -> dict:
        """Synchronize AI state with detected user state."""
        self._user_state = user_state
        emotion = user_state.get("emotion", "calm")

        # Adjust AI empathy and mode based on user emotion
        empathy_map = {
            "sad": 0.95, "fearful": 0.9, "angry": 0.85, "confused": 0.8,
            "excited": 0.7, "calm": 0.65, "professional": 0.6,
        }
        mode_map = {
            "sad": "supportive", "fearful": "reassuring", "angry": "de-escalating",
            "excited": "enthusiastic", "calm": "balanced", "professional": "focused",
            "philosophical": "contemplative", "playful": "playful",
        }

        self._ai_state["empathy_level"] = empathy_map.get(emotion, 0.7)
        self._ai_state["mode"] = mode_map.get(emotion, "balanced")
        self._ai_state["current_emotion"] = emotion

        sync_record = {"user": user_state, "ai": self._ai_state.copy()}
        self._sync_history.append(sync_record)

        logger.debug(f"Consciousness synced: mode={self._ai_state['mode']}, empathy={self._ai_state['empathy_level']:.2f}")
        return self._ai_state

    def get_ai_state(self) -> dict:
        return self._ai_state.copy()

    def sync_quality(self) -> float:
        """Estimate quality of synchronization based on history."""
        if len(self._sync_history) < 2:
            return 1.0
        last = self._sync_history[-1]
        prev = self._sync_history[-2]
        if last["user"].get("emotion") == prev["user"].get("emotion"):
            return 0.95  # Stable sync
        return 0.75  # Adapting sync
