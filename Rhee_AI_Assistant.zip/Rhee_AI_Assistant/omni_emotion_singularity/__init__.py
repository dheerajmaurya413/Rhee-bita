"""Package: omni_emotion_singularity"""
from .emotion_quantization import OmniEmotionSingularityQuantizer
from .singularity_synthesis import EmotionSingularitySynthesizer

__all__ = ["OmniEmotionSingularityQuantizer", "EmotionSingularitySynthesizer"]
