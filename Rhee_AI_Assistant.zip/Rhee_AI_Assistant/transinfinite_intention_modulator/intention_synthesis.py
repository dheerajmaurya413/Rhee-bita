"""Intention Synthesis - Extracts and synthesizes user intentions from input."""
import re
from typing import Optional
from loguru import logger

INTENTION_PATTERNS = {
    "query": r"\b(what|who|where|when|why|how|tell me|explain|describe)\b",
    "command": r"\b(do|make|create|generate|write|build|run|execute|start|stop)\b",
    "emotional": r"\b(feel|feeling|emotion|love|hate|happy|sad|angry|scared)\b",
    "philosophical": r"\b(meaning|purpose|existence|reality|consciousness|soul|universe)\b",
    "creative": r"\b(imagine|story|poem|song|art|dream|fantasy|invent)\b",
    "social": r"\b(talk|chat|friend|together|share|connect|help me)\b",
    "analytical": r"\b(analyze|compare|evaluate|assess|measure|calculate|logic)\b",
    "spiritual": r"\b(meditate|pray|transcend|divine|spirit|energy|enlighten)\b",
}

class IntentionSynthesizer:
    """Synthesizes primary and secondary user intentions from raw input."""

    def __init__(self):
        self._compiled = {k: re.compile(v, re.IGNORECASE) for k, v in INTENTION_PATTERNS.items()}
        logger.info("IntentionSynthesizer initialized")

    def synthesize(self, text: str) -> dict:
        """Synthesize full intention profile from text."""
        scores = {}
        for intent, pattern in self._compiled.items():
            matches = pattern.findall(text)
            if matches:
                scores[intent] = len(matches)

        if not scores:
            primary = "query"
        else:
            primary = max(scores, key=scores.get)

        secondary = [k for k in scores if k != primary]
        confidence = min(1.0, max(scores.values()) / 3) if scores else 0.3

        logger.debug(f"Synthesized intention: {primary} (confidence={confidence:.2f})")
        return {
            "primary": primary,
            "secondary": secondary,
            "confidence": confidence,
            "raw_scores": scores,
        }

    def classify_urgency(self, text: str) -> str:
        """Classify the urgency level of the input."""
        urgent_words = ["urgent", "immediately", "now", "asap", "emergency", "critical", "help"]
        text_lower = text.lower()
        if any(w in text_lower for w in urgent_words):
            return "high"
        elif "?" in text or "!" in text:
            return "medium"
        return "low"
