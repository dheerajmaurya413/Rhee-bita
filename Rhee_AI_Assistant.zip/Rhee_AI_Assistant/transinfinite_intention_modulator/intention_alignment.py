"""Intention Alignment - Aligns detected intentions with system capabilities."""
from loguru import logger

CAPABILITY_MAP = {
    "query": ["knowledge_retrieval", "fact_checking", "explanation"],
    "command": ["task_execution", "code_generation", "action_planning"],
    "emotional": ["empathy_response", "emotional_support", "voice_modulation"],
    "philosophical": ["deep_reasoning", "consciousness_reflection", "wisdom_synthesis"],
    "creative": ["content_generation", "storytelling", "imagination_engine"],
    "social": ["conversation", "rapport_building", "active_listening"],
    "analytical": ["data_analysis", "logical_reasoning", "comparison"],
    "spiritual": ["mindfulness_guidance", "spiritual_reflection", "transcendence_synthesis"],
}

class IntentionAligner:
    """Aligns user intentions with the system's capability matrix."""

    def align(self, intention_profile: dict) -> dict:
        """Map intention profile to system capabilities."""
        primary = intention_profile.get("primary", "query")
        secondary = intention_profile.get("secondary", [])
        capabilities = CAPABILITY_MAP.get(primary, ["general_response"])
        for sec in secondary:
            capabilities += CAPABILITY_MAP.get(sec, [])
        capabilities = list(dict.fromkeys(capabilities))  # deduplicate preserving order

        logger.debug(f"Aligned {primary} intention to capabilities: {capabilities[:3]}")
        return {
            "primary_intent": primary,
            "activated_capabilities": capabilities,
            "alignment_confidence": intention_profile.get("confidence", 0.5),
        }
