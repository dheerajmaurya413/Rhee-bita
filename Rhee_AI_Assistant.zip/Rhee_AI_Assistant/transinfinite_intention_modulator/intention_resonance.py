"""Intention Resonance - Resonates current intention with historical patterns."""
from collections import Counter
from loguru import logger

class IntentionResonance:
    """Tracks intention history and computes resonance with current intent."""

    def __init__(self, history_limit: int = 100):
        self._history: list = []
        self.history_limit = history_limit

    def record(self, intention: str) -> None:
        self._history.append(intention)
        if len(self._history) > self.history_limit:
            self._history.pop(0)

    def resonate(self, current: str) -> float:
        """Return resonance score: how frequently this intention appears historically."""
        if not self._history:
            return 0.5
        counts = Counter(self._history)
        total = len(self._history)
        return counts.get(current, 0) / total

    def dominant_intention(self) -> str:
        """Return the historically dominant intention."""
        if not self._history:
            return "query"
        return Counter(self._history).most_common(1)[0][0]

    def intention_trajectory(self) -> list:
        """Return last 5 intentions as trajectory."""
        return self._history[-5:]
