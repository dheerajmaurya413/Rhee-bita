"""Package: quantum_ethical_singularity"""
from .ethical_quantization import QuantumEthicalSingularityQuantizer
from .singularity_synthesis import EthicsSingularitySynthesizer

__all__ = ["QuantumEthicalSingularityQuantizer", "EthicsSingularitySynthesizer"]
