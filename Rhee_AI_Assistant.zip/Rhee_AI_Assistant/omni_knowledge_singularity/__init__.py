"""Package: omni_knowledge_singularity"""
from .knowledge_quantization import OmniKnowledgeSingularityQuantizer
from .singularity_synthesis import KnowledgeSingularitySynthesizerO

__all__ = ["OmniKnowledgeSingularityQuantizer", "KnowledgeSingularitySynthesizerO"]
