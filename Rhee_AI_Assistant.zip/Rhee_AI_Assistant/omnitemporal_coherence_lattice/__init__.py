"""Package: omnitemporal_coherence_lattice"""
