"""Package: omniversal_ethical_resonator"""
from .ethical_synthesis import OmniversalEthicalSynthesizer
from .resonance_optimization import EthicsResonanceOptimizer

__all__ = ["OmniversalEthicalSynthesizer", "EthicsResonanceOptimizer"]
