"""Package: omniresonant_consciousness"""
from .consciousness_harmonics import ConsciousnessHarmonics
from .resonance_synthesis import ResonanceSynthesizer

__all__ = ["ConsciousnessHarmonics", "ResonanceSynthesizer"]
