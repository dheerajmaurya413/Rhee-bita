"""Package: hyperconsciousness_intention_core"""
from .intention_synthesis import HyperconsciousnessIntentionSynthesizer
from .consciousness_coherence import IntentionConsciousnessCoherence

__all__ = ["HyperconsciousnessIntentionSynthesizer", "IntentionConsciousnessCoherence"]
