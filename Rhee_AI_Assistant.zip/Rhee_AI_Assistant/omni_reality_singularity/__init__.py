"""Package: omni_reality_singularity"""
from .reality_quantization import OmniRealityQuantizer
from .singularity_synthesis import OmniRealitySingularitySynthesizer

__all__ = ["OmniRealityQuantizer", "OmniRealitySingularitySynthesizer"]
