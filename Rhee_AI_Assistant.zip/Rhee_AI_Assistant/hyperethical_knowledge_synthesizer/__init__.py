"""Package: hyperethical_knowledge_synthesizer"""
from .knowledge_synthesis import HyperEthicalKnowledgeSynthesizer
from .ethical_coherence import KnowledgeEthicsCoherence

__all__ = ["HyperEthicalKnowledgeSynthesizer", "KnowledgeEthicsCoherence"]
