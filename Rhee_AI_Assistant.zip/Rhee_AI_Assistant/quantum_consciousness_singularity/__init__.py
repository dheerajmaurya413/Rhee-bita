"""Package: quantum_consciousness_singularity"""
from .consciousness_quantization import QuantumConsciousnessQuantizer
from .singularity_synthesis import ConsciousnessSingularitySynthesizer

__all__ = ["QuantumConsciousnessQuantizer", "ConsciousnessSingularitySynthesizer"]
