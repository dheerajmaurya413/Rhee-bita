"""Package: omniversal_intention_nexus"""
from .intention_quantization import OmniversalIntentionQuantizer
from .nexus_coherence import IntentionNexusCoherence

__all__ = ["OmniversalIntentionQuantizer", "IntentionNexusCoherence"]
