"""Package: quantum_emotion_resonator"""
from .emotion_synthesis import QuantumEmotionSynthesizer
from .resonance_amplification import EmotionResonanceAmplifier

__all__ = ["QuantumEmotionSynthesizer", "EmotionResonanceAmplifier"]
