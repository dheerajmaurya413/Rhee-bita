"""Package: infniversal_ethical_synthesizer"""
from .ethical_quantization import InfniversalEthicalQuantizer
from .synthesis_amplification import EthicsSynthesisAmplifierI

__all__ = ["InfniversalEthicalQuantizer", "EthicsSynthesisAmplifierI"]
